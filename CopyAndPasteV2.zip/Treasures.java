public class Treasures
{
  private boolean treasureOne;
  private boolean treasureTwo;
  private boolean treasureThree;
  private String treasureNameA;
  private String treasureNameB;
  private String treasureNameC;

  public Treasures()
  {
    treasureOne = false;
    treasureTwo = false;
    treasureThree = false; 
    treasureNameA = "Goblet of Osiris, the god";
    treasureNameB = "Talons of Smalug, the ancient dragon";
    treasureNameC = "Rubber Boot (Owned by Shrek)";
  }

  public boolean getTreasureOne() { return treasureOne; }
  public boolean getTreasureTwo() { return treasureTwo; }
  public boolean getTreasureThree(){ return treasureThree; }
  //Changes the boolean private variable, treasureOne, to true if false and if true, says "You already got this treasure!"
  public void giveTreasureOne()
  {
    if (treasureOne == true)
    {
      System.out.println("You've already got the " + treasureNameA + "!\nYou shrug and toss the duplicate aside.");
    }
    else{
      System.out.println("Ye've found the exotic " + treasureNameA + "! Good job hunter!");
      treasureOne = true;
      
    }
  }
  //Changes the boolean private variable, treasureTwo, to true if false and if true, says "You already got this treasure!"
  public void giveTreasureTwo(){
    if (treasureTwo == true)
    {
      System.out.println("You've already got the " + treasureNameB + "!\nYou shrug and toss the duplicate aside.");
    }
    else {
      System.out.println("Ye've found the mythical " + treasureNameB + "! Good job hunter!");
      treasureTwo = true;
    }
  }
  //Changes the boolean private variable, treasureThree, to true if false, and if true, says "You already got this treasure!"
  public void giveTreasureThree()
  {
    if (treasureThree == true)
    {
      System.out.println("You've already got a " + treasureNameC + ", why do you need more???\nYou shrug and toss the duplicate " + treasureNameC + " aside. (Should've worn both if you ask me)");
    }
    else{
      System.out.println("Ye've found the legendary " +  treasureNameC + "! Good job hunter!");
      treasureThree = true;
    }
  }
public String toString(){
  String str = "";
  if (treasureOne){
    str += (" and " + treasureNameA);
  }
  if (treasureTwo){
    str += (" and " + treasureNameB);
  }
  if (treasureThree){
    str += (" and " + treasureNameC);
  }
  return str;
}
  
  public boolean hasAllTreasure()
  {
    boolean won = true;
    if (!treasureOne)
    {
      won = false;
    }
    if (!treasureTwo)
    {
      won = false;
    }
    if (!treasureThree)
    {
      won = false;
    }
    return won;
  }
}